package homework;

public class homework1 {

	public static void main(String[] args) {
		

	}

}
